# SwiftMixObjectiveCModule

[![CI Status](https://img.shields.io/travis/satori's mini/SwiftMixObjectiveCModule.svg?style=flat)](https://travis-ci.org/satori's mini/SwiftMixObjectiveCModule)
[![Version](https://img.shields.io/cocoapods/v/SwiftMixObjectiveCModule.svg?style=flat)](https://cocoapods.org/pods/SwiftMixObjectiveCModule)
[![License](https://img.shields.io/cocoapods/l/SwiftMixObjectiveCModule.svg?style=flat)](https://cocoapods.org/pods/SwiftMixObjectiveCModule)
[![Platform](https://img.shields.io/cocoapods/p/SwiftMixObjectiveCModule.svg?style=flat)](https://cocoapods.org/pods/SwiftMixObjectiveCModule)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

SwiftMixObjectiveCModule is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'SwiftMixObjectiveCModule'
```

## Author

satori's mini, tamama00792@sina.com

## License

SwiftMixObjectiveCModule is available under the MIT license. See the LICENSE file for more info.

//
//  SMOSwiftMethodCaller.h
//  SwiftMixObjectiveCModule
//
//  Created by 徐冰 on 2024/3/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SMOSwiftMethodCaller : NSObject

- (void)logSwiftUtilInsideSamePod;

+ (void)logSwiftUtilInsideSamePod;

@end

NS_ASSUME_NONNULL_END
